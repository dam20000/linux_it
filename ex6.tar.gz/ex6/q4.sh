ssh daniel.mandelbaum@194.153.101.137 mkdir /home/daniel.mandelbaum/backup/
rsync -avzh /home/daniel/ daniel.mandelbaum@194.153.101.137:/home/daniel.mandelbaum/backup
ssh daniel.mandelbaum@194.153.101.137 tar -cvzf backup.tar.gz backup
ssh daniel.mandelbaum@194.153.101.137 rm -r backup
