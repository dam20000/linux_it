printf 'daniel.mandelbaum'
