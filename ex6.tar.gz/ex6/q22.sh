ssh -vvv daniel.mandelbaum@194.153.101.137 "echo test" 2>&1 | grep "Authentication succeeded"
